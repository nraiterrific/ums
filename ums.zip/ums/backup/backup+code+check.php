<?php
error_reporting(0);
include("php/header-admin.php");

?>
<?php
  $get_id=$_GET['tb_admin'];

      if(isset($_POST['submit'])) {

        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $username=$_POST['username'];
        $name=$_POST['name'];

        $dupe= $conn ->prepare("SELECT SQL_CALC_FOUND_ROWS * FROM tb_admin WHERE username='$username'");
        $dupe->execute();
        $dupe = $conn->prepare("SELECT FOUND_ROWS()");
        $dupe->execute();
        $row_count =$dupe->fetchColumn();

        if($row_count>0){
          $wrong="Already Exists";
        } else {
          $sql = "UPDATE tb_admin SET name=:name,username=:username WHERE id=$get_id";

          $stmt = $conn->prepare($sql);
          $stmt -> bindParam (":name", $name, PDO::PARAM_STR);
          $stmt -> bindParam (":username", $username , PDO::PARAM_STR);
          $stmt->execute();
          echo "<script>window.location='profile-admin.php'</script>";

        }

      };

    /***********************************************************************/
    $sql2 = $conn ->prepare("SELECT * FROM tb_admin WHERE id='$get_id'");
    $sql2 ->execute();
    for($i=0; $row2 = $sql2->fetch(); $i++)
    {
      $id = $row2['id'];
?>
