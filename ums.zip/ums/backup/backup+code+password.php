<?php
  try{
    if(isset($_POST['submit'])) {

        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $password = md5($_POST['password']);
        $new_pass =md5($_POST['new_pass']);
        $re_pass =md5($_POST['re_pass']);
        $username =md5($_SESSION['sess_admin_name']);

        $sql2 = $conn->prepare("SELECT * FROM tb_admin WHERE username='$username'");
        //$sql2="SELECT * FROM tb_admin WHERE username=";
        $sql2 ->execute();
        for($i=0; $row2 = $sql2->fetch(); $i++)
        {
          $passwordb = $row2['password'];

          if(!$sql2)
          {
            echo "ERROR, Unexisted User";
          }
          else if($password!=fetch())
          {
            ?> <script>
            alert('password dont match');
            window.location.href='profile-password-admin.php';
            </script> <?php
          }
          if($password==$passwordb)
          {
            if($new_pass==$re_pass)
            {
              $sql = "UPDATE tb_admin SET password=:password, new_pass=:new_pass, re_pass=:re_pass WHERE username='$username'";

              $stmt = $conn->prepare($sql);
              $stmt -> bindParam (":password", $new_pass, PDO::PARAM_STR);
              $stmt -> bindParam (":new_pass", $new_pass, PDO::PARAM_STR);
              $stmt -> bindParam (":re_pass", $re_pass, PDO::PARAM_STR);
              $stmt->execute();
                      ?>
                      <script>
                      alert('Password changed!');
                      window.location.href='profile-admin.php';
                      </script> <?php
            }
            else if ($new_pass!=$re_pass)
            {
              ?>
              <script>
              alert('Wrong match!');
              window.location.href='profile-password-admin.php';
              </script> <?php
            }
            else
            {
              ?> <script>
              alert('Error, new password and confirm password must be the same');
              window.location.href='profile-admin.php';
              </script> <?php
            }
          }
        }
      }
    } catch(PDOException $e){
        die("ERROR: Could not able to execute $sql2. " . $e->getMessage());
    }

    /***********************************************************************/

?>


<?php
  $get_id=$_GET['tb_admin'];

  try{
      if(isset($_POST['submit'])) {

        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          $sql = "UPDATE tb_admin SET name=:name, username=:username WHERE id=$get_id";

          $stmt = $conn->prepare($sql);
          $stmt -> bindParam (":name", $_POST['name'], PDO::PARAM_STR);
          $stmt -> bindParam (":username", $_POST['username'], PDO::PARAM_STR);

          $stmt->execute();
          echo "<script>window.location='profile-admin.php'</script>";

      }
    } catch(PDOException $e){
        die("ERROR: Could not able to execute $sql2. " . $e->getMessage());
    }

    /***********************************************************************/
    $sql2 = $conn ->prepare("SELECT * FROM tb_admin WHERE id='$get_id'");
    $sql2 ->execute();
    for($i=0; $row2 = $sql2->fetch(); $i++)
    {
      $id = $row2['id'];
?>
