<?php
include("php/header-admin.php") ;
//error_reporting(0);

  $get_id=$_GET['tb_quiz_modul'];

  $row_page = 10;

  if(isset($_POST['num_rows'])){
      $row_page = $_POST['num_rows'];
  }

  $sql2 = $conn ->prepare("SELECT * FROM tb_question WHERE category = '' LIMIT $row_page");
  $sql2 ->execute();

  if(isset($_POST['submit'])) {

      $ums = $_POST['quest_id'];

      if(count($ums)> 0)
      {
        foreach($ums as $qqq)
        {
          echo $qqq;

          $s = $conn ->prepare("SELECT * FROM tb_question WHERE id='$qqq'");
          $s ->execute();
          for($i=1; $row2 = $s->fetch(); $i++)
          {
            $id_question = uniqid();
            $quest = $row2['quest'];
            $quest_id = $row2['quest_id'];

            $sql = "INSERT INTO tb_question (quest_id, quest, category)
                    VALUES ('$id_question','$quest', '$get_id')";
            $stmt = $conn->prepare($sql);
            $stmt->execute();


            $s13 = $conn ->prepare("SELECT * FROM tb_question_media WHERE quest_id='$quest_id'");
            $s13 ->execute();

            for($i13=1; $row213 = $s13->fetch(); $i13++)
            {
                $name= $row213['name'];
                $media= $row213['media'];
                $type= $row213['type'];


                $sql13= "INSERT INTO tb_question_media (quest_id,name,media,type,category) VALUES ('$id_question','$name','$media','$type','$get_id')";
                $stmt13 = $conn->prepare($sql13);
                $stmt13->execute();

            }

            $s1 = $conn ->prepare("SELECT * FROM tb_choices WHERE quest_id='$quest_id'");
            $s1 ->execute();

            for($i1=1; $row21 = $s1->fetch(); $i1++)
            {
                $choices= $row21['choices'];
                $is_right= $row21['is_right'];

                $sql1= "INSERT INTO tb_choices (choices, is_right,category,quest_id) VALUES ('$choices','$is_right','$get_id','$id_question')";
                $stmt1 = $conn->prepare($sql1);
                $stmt1->execute();

            }
        }

          $message = 'Questions have been successfully added';
          echo '<script type="text/javascript">alert("'.$message.'");</script>';
          ?>
          <script>
          window.location.href='quiz-create1.php<?php echo '?tb_quiz_modul='.$get_id; ?>';
          </script>
          <?php

        }
      }
      else {
        $message = 'Please select the question';
        echo '<script type="text/javascript">alert("'.$message.'");</script>';
      }
  }


?>


<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Question Bank</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>



<section class="" id="aboutUs" style="padding-top:0px;margin-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-2 col-md-2 col-sm-2"></div>

      <div class="col-lg-8 col-md-8 col-sm-8 wow fadeInLeft delay-03s text-purple card" style="">

        <form method="post" action="" id="form1">
          <p class="text-right">Number of row</p>
          <select id="num_rows" name="num_rows" class="aa16 input-text3">
              <?php
              $numrows_arr = array("10","20","50","100","250","500","1000");
              foreach($numrows_arr as $nrow){
                  if(isset($_POST['num_rows']) && $_POST['num_rows'] == $nrow){
                      echo '<option value="'.$nrow.'" selected="selected">'.$nrow.'</option>';
                  }else{
                      echo '<option value="'.$nrow.'">'.$nrow.'</option>';
                  }
              }
              ?>
          </select>
        </form>

        <form method="post" enctype="multipart/form-data" style="border:none;">

          <table class='tbl-qa gfg' style="width:100%;" >
            <tbody id='table-body'>

              <thead class="desk-v">
              	<tr class="aa18">
              	  <th class='table-header geeks'></th>
              	  <th class='table-header geeks'>Question</th>
                  <th class='table-header geeks'>Chapter</th>
                  <th class='table-header geeks'>Answer</th>
              	</tr>
              </thead>

            <?php


              for($i=0; $row2 = $sql2->fetch(); $i++)
              {
                  $id = $row2['id'];
                  $q_id = $row2['quest_id'];
            ?>

             <!-- desk view ---------------------------------------------->
              <tr class='table-row card1 desk-v' style="margin-top:-20px;">
                <td><input type="checkbox" class="" name="quest_id[]" value="<?php echo $id ?>" style="margin-left:15px;"></td>
                <td class="geeks" style='padding:10px;'><h5 class="title-learn " style="padding-left:10px;"><?php echo $row2['quest']; ?></h5></td>
                <td class="geeks"  style='padding:10px;'><?php echo $row2['chapter']; ?></td>
                <?php
                  $s11 = $conn ->prepare("SELECT * FROM tb_choices WHERE quest_id='$q_id' AND is_right='1'");
                  $s11 ->execute();
                  for($i11=1; $row211 = $s11->fetch(); $i11++)
                  {
                ?>
                <td class="geeks"  style='padding:10px;'><?php echo $row211['choices']; ?></td>
              <?php } ?>
              </tr>
              <!--------------------------------------------------------->

              <!-- mobile view ---------------------------------------------->
              <tr class='mobile-v table-row card1' style="height:auto;margin-top:20px;padding-bottom:50px;">
                <td><input type="checkbox" class="" name="quest_id[]" value="<?php echo $id ?>" style="margin-left:15px;"></td>
                <td class="geeks" style='padding:10px;'><h5 class="title-learn " style="padding-left:10px;"><?php echo $row2['quest']; ?></h5></td>
                <td class="geeks"  style='padding:10px;'>[ Chapter <?php echo $row2['chapter']; ?> ]</td>
              </tr>
              <!-------------------------------------------------------------->

              <?php
              }
            ?>

            <tr>
              <td colspan='4'><br>
                <input id="btn-add" class="t-b-t" name="submit" type="submit" value="Submit" style="float:is_right">
              </td>
            </tr>

            </tbody>


          </table>

        </form>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-2"></div>


  </div>
  </div>
</section>


<?php include("php/footer-admin.php"); ?>

<script>
$(document).ready(function(){

    // Number of rows selection
    $("#num_rows").change(function(){

        // Submitting form
        $("#form1").submit();

    });
});
</script>
