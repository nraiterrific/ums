<?php

include("php/header-admin.php") ;

    $get_id=$_GET['tb_chapter_audio'];

    if(isset($_POST['submit'])) {

        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $filetemp = $_FILES['files']['tmp_name'];
        $filename = $_FILES['files']['name'];
        $filetype = $_FILES['files']['type'];
        $filepath = "upload/content-chapter/audio".$filename;

        move_uploaded_file($filetemp,$filepath);

        if(!empty($filename)){

          $sql = "UPDATE tb_chapter_audio SET name = :name,audio = :audio,type = :type,c_word = :c_word,p_word = :p_word,e_word = :e_word WHERE id = '$get_id'";

          $stmt = $conn->prepare($sql);
          $stmt -> bindParam (":name", $filename, PDO::PARAM_STR);
          $stmt -> bindParam (":audio", $filepath, PDO::PARAM_STR);
          $stmt -> bindParam (":type", $filetype, PDO::PARAM_STR);
          $stmt -> bindParam (":c_word", $_POST['c_word'], PDO::PARAM_STR);
          $stmt -> bindParam (":p_word", $_POST['p_word'], PDO::PARAM_STR);
          $stmt -> bindParam (":e_word", $_POST['e_word'], PDO::PARAM_STR);

          $stmt->execute();

          ?>
          <script>
          alert('Successfully updated !!');
    			</script>
          <?php
        }
        else {

          $sql = "UPDATE tb_chapter_audio SET c_word = :c_word,p_word = :p_word,e_word = :e_word WHERE id = '$get_id'";


          $stmt = $conn->prepare($sql);
          $stmt -> bindParam (":c_word", $_POST['c_word'], PDO::PARAM_STR);
          $stmt -> bindParam (":p_word", $_POST['p_word'], PDO::PARAM_STR);
          $stmt -> bindParam (":e_word", $_POST['e_word'], PDO::PARAM_STR);

          $stmt->execute();

          ?>
          <script>
          alert('Successfully updated !!');
    			</script>
          <?php

        }
    }

      $sql = $conn ->prepare("SELECT * FROM tb_chapter_audio WHERE id=$get_id");
      $sql ->execute();
      for($i=0; $row2 = $sql->fetch(); $i++)
      {
        $id12 = $row2['category'];

?>

<style>
input:read-only { background: #bbbbbb; }
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Update Chapter Content (Audio)</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card">
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <br>
          <p class="t-w"><strong>Content Audio Pronounciation</strong></p>
          <br>

          <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label>Upload Audio</label>
              <input type="file" class="input-text3" name="files" value="" >
              <br>
              <h5><label>Data Audio</label></h5>
              <p><?php echo $row2['name']; ?></p>
              <audio controls>
                <source src="<?php echo $row2['audio']; ?>" type="<?php echo $row2['type']; ?>">
                Your browser does not support the audio element.
              </audio>
              <br><br><br>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Mandarin Words</label>
              <input class="input-text3" type="text" name="c_word" value="<?php echo $row2['c_word']; ?>" >
            </div>

          </div>

          <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Pronounciation in words</label>
              <input class="input-text3" type="text" name="p_word" value="<?php echo $row2['p_word']; ?>" >
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Meaning in English</label>
              <input class="input-text3" type="text" name="e_word" value="<?php echo $row2['e_word']; ?>" >
            </div>

          </div>

          <button id="btn-add" class="t-b-t" name="submit" type="submit">Update</button>

          <br>
          <br><Br><Br><br>

          <!--<label class="">Confirm Password</label>
          <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

        </form>
      </div>

    </div>

  </div>
  </div>
</section>


<section>
  <div class="form">
    <center><a href="chapter-audio-update.php<?php echo '?tb_chapter_audio='.$id12; ?>"><input class="input-btn" type="submit" value="Back" style="width:50%;background:#392560"></a></center>
</div>
</section>


<br><br>

<?php } ?>



<?php include("php/footer-admin.php"); ?>
