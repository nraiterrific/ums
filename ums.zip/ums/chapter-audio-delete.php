
    <?php
    require_once('connection.php');

    $get_id=$_GET['tb_chapter_audio'];

    // sql to delete a record
		$sql2 = $conn ->prepare("SELECT * FROM tb_chapter_audio WHERE id='$get_id'");
	  $sql2 ->execute();
	  for($i=0; $row2 = $sql2->fetch(); $i++)
	  {

			$id_chap=$row2['category'];

	    $sql = "Delete from tb_chapter_audio where id = '$get_id'";

			// use exec() because no results are returned
			$conn->exec($sql); ?>


			<script>
			alert('Successfully deleted !');
			window.location.href='chapter-audio1.php<?php echo '?tb_chapter_audio='.$id_chap; ?>';
			</script>

		<?php } ?>
