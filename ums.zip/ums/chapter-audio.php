<?php

include("php/header-admin.php") ;

    $get_id=$_GET['tb_chapter'];

    if(isset($_POST['submit'])) {


      $category = $get_id;
      $c_word=$_POST['c_word'];
      $p_word=$_POST['p_word'];
      $e_word=$_POST['e_word'];

      $filetemp = $_FILES['files']['tmp_name'];
      $filename = $_FILES['files']['name'];
      $filetype = $_FILES['files']['type'];
      $filepath = "upload/content-chapter/audio/".$filename;


      $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, 1);

      move_uploaded_file($filetemp,$filepath);

      // Prepared statement
      $query = "INSERT INTO tb_chapter_audio (name,audio,category,type,c_word,p_word,e_word)
                VALUES('$filename','$filepath','$get_id','$filetype','$c_word','$p_word','$e_word')";
      $statement = $conn->prepare($query);
      $statement->execute();

      }

?>

<style>
input:read-only { background: #bbbbbb; }
}
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Create New Chapter</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card">
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <br>
          <p class="t-w"><strong>Content Audio Pronounciation</strong></p>
          <br>

          <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label>Upload Audio</label>
              <input type="file" class="input-text3" name="files" >
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Mandarin Words</label>
              <input class="input-text3" type="text" name="c_word" value="" >
            </div>

          </div>

          <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Pronounciation in words</label>
              <input class="input-text3" type="text" name="p_word" value="" >
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Meaning in English</label>
              <input class="input-text3" type="text" name="e_word" value="" >
            </div>

          </div>

          <input id="btn-add" class="t-b-t" name="submit" type="submit" value="Add More">

          <br><Br><Br><br>


          <!--*****************************************-table display------------------------------------->
          <div class="row">


                <?php
                $sql2 = $conn ->prepare("SELECT * FROM tb_chapter_audio WHERE category='$get_id'");
            	  $sql2 ->execute();
            	  for($i=0; $row2 = $sql2->fetch(); $i++)
            	  {
                    $id = $row2['id'];
                    $chapter_id = $row2['category'];
                ?>

                <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft up2 delay-06s">
                  <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up2 text-purple card2">
                    <a class="text-purple" href="chapter-audio-delete.php<?php echo '?tb_chapter_audio='.$id; ?>" onclick="return confirm('Are you sure want to delete?')">
                        <div class="btn-icon3 aa11">
                        <center>
                          <i class="i-con22 fa fa-remove" style="font-size:25px;"></i>
                        </center>
                      </div>
                    </a>
                    <h4 class="title-learn " style="padding-left:10px;"><?php echo $row2['c_word']; ?></h4>
                    <h5 class="title-learn " style="padding-left:10px;"><?php echo $row2['p_word']; ?></h5>
                    <h5 class="title-learn " style="padding-left:10px;"><?php echo $row2['e_word']; ?></h5>
                    <audio controls>
                      <source src="<?php echo $row2['audio']; ?>" type="<?php echo $row2['type']; ?>">
                      Your browser does not support the audio element.
                    </audio>

                    </div>
                </div>

                  <?php
                }
                ?>
          </div>
          <!--*****************************************-table display------------------------------------->



          <!--<label class="">Confirm Password</label>
          <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

          <br><br><br>
          <a href="chapter-admin.php"><input class="input-btn" onclick="alert('Successfully inserted !')" value="Submit" style="width:100%; text-align:center;cursor:pointer;"></a>
        </form>
      </div>

    </div>

  </div>
  </div>
</section>


<?php include("php/footer-admin.php"); ?>
