<?php

include("php/header-admin.php") ;

    if(isset($_POST['submit'])) {


      try{

        $id_chapter =uniqid();
        $chapter=$_POST['chapter'];
        $title=$_POST['title'];
        $content=$_POST['content'];
        $detail=$_POST['detail'];
        $admin_id=$_SESSION['sess_admin_id'];

        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          // Loop all files
          for($io=0; $io < count($_FILES['files']['name']); $io++){
              // File name
              $filetemp = $_FILES['files']['tmp_name'][$io];
              $filename = $_FILES['files']['name'][$io];
              $filetype = $_FILES['files']['type'][$io];
              $filepath = "upload/content-chapter/".$filename;
              $size = $_FILES['files']['size'][$io];

                if($filename){
                    if($size < 100097152){
                      move_uploaded_file($filetemp,$filepath);
                      $query = "INSERT INTO tb_chapter_media (name,media,category,type) VALUES('$filename','$filepath','$id_chapter','$filetype')";
                      $statement = $conn->prepare($query);
                      $statement->execute();
                    }
                    else {
                      $message = 'File too large. File must be less than 100 megabytes.';
                      echo '<script type="text/javascript">alert("'.$message.'");</script>';
                      ?>
                      <script>
                			window.location.href='chapter-create.php';
                			</script>
                      <?php
                    }
                }
            }

            if(!$message)
            {
              $sql = "INSERT INTO tb_chapter (chapter_id, chapter, title, content, detail, admin_id) VALUES ('$id_chapter','$chapter', '$title', '$content', '$detail', '$admin_id')";
              $stmt = $conn->prepare($sql);
              $stmt->execute();

              ?>
              <script>
        			window.location.href='chapter-audio.php<?php echo '?tb_chapter='.$id_chapter; ?>';
        			</script>
              <?php
            }


        }
        catch(PDOException $e)
        {
         echo $e->getMessage();
        }

      }

?>

<style>
input:read-only { background: #bbbbbb; }
}
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Create New Chapter</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>

      <div class="col-lg-8 col-md-8 col-sm-10 wow fadeInLeft delay-06s up1 text-purple card">
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <label class="">Chapter</label>
          <input class="input-text3" type="number" name="chapter" value="" placeholder="Please insert number of chapter" min="1" max="200" required>

          <label class="">Title </label>
          <input class="input-text3" type="text" name="title" value="" maxlength="150" required>

          <label>Upload Video Lesson</label>
          <input type="file" class="input-text3" name="files[]" multiple>

          <label class="">Description </label>
          <textarea class="input-text3 text-area" name="content" cols="5" rows="5" maxlength="500" ></textarea>

          <br>
          <p class="t-w"><strong>Details</strong></p>
          <br>

          <label class="">Explaination chapter content </label>
          <textarea class="input-text3 text-area" name="detail" cols="5" rows="15" maxlength="15000" ></textarea>

          <br>
          <p class="t-w"><strong>Any other document</strong></p>
          <br>

          <label>Upload Document Lesson (for example .doc .pptx .exl .pdf)</label>
          <input type="file" class="input-text3" name="files[]" multiple>

          <!--<label class="">Confirm Password</label>
          <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

          <br>
          <input class="input-btn" name="submit" type="submit" value="Proceed to audio content" style="width:100%">
        </form>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>
    </div>

  </div>
  </div>
</section>


<?php include("php/footer-admin.php"); ?>
