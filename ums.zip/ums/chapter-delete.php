        <?php
        require_once('connection.php');

        $get_id=$_GET['tb_chapter'];

        // sql to delete a record
    		$sql2 = $conn ->prepare("SELECT * FROM tb_chapter WHERE id='$get_id'");
    	  $sql2 ->execute();
    	  for($i=0; $row2 = $sql2->fetch(); $i++)
    	  {

    			$id_chap=$row2['chapter_id'];

    	    $sql = "Delete from tb_chapter where id = '$get_id'";
    			$conn->exec($sql);

          $sql = "Delete from tb_chapter_media where category = '$id_chap'";
    			$conn->exec($sql);

          $sql = "Delete from tb_chapter_audio where category = '$id_chap'";
    			$conn->exec($sql);


          ?>


    			<script>
    			alert('Successfully deleted !');
    			window.location.href='chapter-admin.php';
    			</script>

    		<?php } ?>
