<?php

//database connection
require "connection.php";

// Users search terms is saved in $_POST['q']
$q = $_POST['q'];
// Create array for the names that are close to or match the search term
$results = array();
foreach($db->query('SELECT `id`, `name` FROM `employees`') as $name) {
  // Keep only relevant results
  // First takes the phonetic keys from each word, and compares the difference between them
  // If more than 3 charachters need to be added, deleted, or replaced, the word is thrown out
  // To get broader results, change the 3 to a higher number (and vice versa — for narrower results use a number below 3)
  if (levenshtein(metaphone($q), metaphone($name['name'])) < 3) {
    array_push($results,$name['name']);
  }
}
// Echo out results
foreach ($results as $result) {
  echo $result."\n";
}



    if(isset($_GET['form_submit']))
    {
      $title =$_GET['title'];
      $sql = $conn->prepare("SELECT * FROM tb_chapter WHERE title=:title");

      $stmt = $conn->prepare("select * from tb_chapter where title=? ");
      $stmt->bind_param('s',$title);
      $stmt->execute();
      $val =  $stmt->get_result();
      $row_count= $val->num_rows;
      if($row_count>0)
      {
          //$result =$val->fetch_assoc();
          //print_r($result);
          for($i=0; $result = $val->fetch(); $i++)
          {
            $id = $result['id'];

            echo $id;

          }
        }
          else
          {
            echo "identification_number not Match";
          }
              $stmt->close();
              $conn->close();

          }


          $stmt = $conn->prepare($sql);
          $stmt -> bindParam (":chapter", $_POST['chapter'], PDO::PARAM_STR);


          $get_id=$_GET['tb_chapter'];
          $sql = $conn ->prepare("SELECT * FROM tb_chapter WHERE id=$get_id");
          $sql ->execute();
          for($i=0; $row2 = $sql->fetch(); $i++)
          {
            $id = $row2['id'];


 ?>

 <?php
 include("php/header-admin.php");
 ?>

 <section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;border-bottom:10px solid #392560;"><!--Aboutus-->
 <div class="inner_wrapper">
   <div class="container">
     <h2><strong>Chapter <?php echo $row2['chapter'] .' : '. $row2['title']; ?></strong></h2>
     <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
     <!--<center>
       <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
       <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
       <img src="img/question.png" alt="logo" width="60">
     </center>-->
     <div class="inner_section">
 	   <div class="row">

     	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
       	<div class=" delay-01s animated fadeInDown wow animated">

         </div>
        </div>
       </div>
      </div>
     </div>
   </div>
 </section>
 <!--bannner-->

 <section id="aboutUs" style="padding-top:70px;"><!--Aboutus-->
 <div class="inner_wrapper">
   <div class="container">

     <div class="row">
       <div class="col-lg-2 col-md-2 col-sm-1">
       </div>

       <div class="col-lg-8 col-md-8 col-sm-10 wow fadeInLeft delay-06s up1 text-purple card ad-margin" style="">
         <h3>Content :</h3>
         <p><?php echo $row2['content']; ?>
       </div>

       <div class="col-lg-2 col-md-2 col-sm-1">
       </div>
     </div>

   </div>
   </div>
 </section>

 <section class="kosong ad-margin">
     <div class="row">
       <div class="col-lg-4 col-md-4 col-sm-0">
       </div>

       <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft delay-06s up1 text-purple" style="">
         <div class="form">
           <a href="chapter-admin.php"><input class="input-btn" name="submit" type="submit" value="Back" style="width:100%"></a>
         </div>
       </div>

       <div class="col-lg-4 col-md-4 col-sm-0">
       </div>
     </div>
 </section>

 <?php }?>


 <?php include("php/footer-admin.php"); ?>
