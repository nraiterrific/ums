<?php

include("php/header-admin.php") ;

$get_id=$_GET['tb_chapter'];

    if(isset($_POST['update'])) {

      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      $sql44 = "UPDATE tb_chapter SET
              chapter=:chapter,
              title=:title,
              detail=:detail,
              content=:content
               WHERE chapter_id='$get_id'";

     $stmt44 = $conn->prepare($sql44);
     $stmt44 -> bindParam (":chapter", $_POST['chapter'], PDO::PARAM_STR);
     $stmt44 -> bindParam (":title", $_POST['title'], PDO::PARAM_STR);
     $stmt44 -> bindParam (":detail", $_POST['detail'], PDO::PARAM_STR);
     $stmt44 -> bindParam (":content", $_POST['content'], PDO::PARAM_STR);
     $stmt44->execute();
     ?>

    <script>
    alert('Successfully updated.');
    </script>
    <?php
  }


  $sql2 = $conn ->prepare("SELECT * FROM tb_chapter WHERE chapter_id='$get_id'");
  $sql2 ->execute();
  for($i=0; $row2 = $sql2->fetch(); $i++)
  {
    $id = $row2['id'];
    $category=$row2['chapter_id'];

?>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto; "><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Update Chapter</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>

      <div class="col-lg-8 col-md-8 col-sm-10 wow fadeInLeft delay-06s up1 text-purple card">
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <a class="text-purple" href="chapter-media-update.php<?php echo '?tb_chapter_media='.$category; ?>"><div class="btn-icon vtew" style="float:right;text-align:center;background:#ffa248;">
            <i class="i-con22 fa fa-refresh" style="font-size:25px;float:left;"></i><center><span style="float:right;font-size:20px;"><strong>Media</strong></span></center></div>
          </a>
          <a class="text-purple" href="chapter-audio-update.php<?php echo '?tb_chapter_audio='.$category; ?>"><div class="btn-icon vtew" style="float:right;text-align:center;background:#ffa248;">
            <i class="i-con22 fa fa-refresh" style="font-size:25px;float:left;"></i><center><span style="float:right;font-size:20px;"><strong>Audio</strong></span></center></div>
          </a>

          <br><BR><BR><BR>
          <label class="">Chapter</label>
          <input class="input-text3" type="number" name="chapter" value="<?php echo $row2['chapter']; ?>" required>

          <label class="">Title</label>
          <input class="input-text3" type="text" name="title" value="<?php echo $row2['title']; ?>"  required>

          <label class="">Description</label>
          <textarea class="input-text3 text-area" name="content" cols="5" rows="5"><?php echo $row2['content']; ?></textarea>

          <label class="">Explaination</label>
          <textarea class="input-text3 text-area" name="detail" cols="5" rows="15"><?php echo $row2['detail']; ?></textarea>

          <!--<label class="">Confirm Password</label>
          <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

          <br><Br>
          <input class="input-btn" name="update" type="submit" value="Update" style="width:100%;">
        </form>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>
    </div>

  </div>
  </div>
</section>

<?php } ?>

<section class="kosong ad-margin">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft delay-06s up1 text-purple" style="">
        <div class="form">
          <a href="chapter-admin.php"><input class="input-btn" name="submit" type="submit" value="Back" style="width:100%;background:#ffa248"></a>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>
    </div>
</section>

<?php include("php/footer-admin.php"); ?>
