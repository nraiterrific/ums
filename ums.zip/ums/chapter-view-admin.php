<?php include("php/header-admin.php"); ?>

<?php
  $get_id=$_GET['tb_chapter'];

  $sql = $conn ->prepare("SELECT * FROM tb_chapter WHERE chapter_id='$get_id'");
  $sql ->execute();
  $row = $sql->fetch();

  $sql1 = $conn ->prepare("SELECT * FROM tb_chapter_audio WHERE category='$get_id'");
  $sql1->execute();

  $sql2 = $conn ->prepare("SELECT * FROM tb_chapter_media WHERE category='$get_id'");
  $sql2 ->execute();
  $row2 = $sql2->fetchAll();

?>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;border-bottom:10px solid #392560;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Chapter <?php echo $row['chapter'] .' : '. $row['title']; ?></strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section id="aboutUs" style="padding-top:70px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card ad-margin" style="">

        <?php
        foreach ($row2 as $try2)
                if($try2['type']=='video/mp4')
                {
            ?>
              <p class="t-w"><strong>Lesson</strong></p>
              <br>
                <video style="width:100%;" controls>
                  <source src="<?php echo $try2['media'] ?>" type="<?php echo $try2['type']; ?>">
                  Your browser does not support the video tag.
                </video>
            <?php
            echo "<br><br><br><br>";
                }


            ?>

            <?php
                if($row['content']!='')
                {
            ?>
            <p class="t-w"><strong>Description</strong></p>
            <br>
            <p><?php echo $row['content']; ?></p>
            <?php
                echo '<br><br>';
                }
            ?>

            <p class="t-w"><strong>Audio for learning</strong></p>
            <br>
            <br>
            <table border='1' style="width:100%;">
              <tr class="up2 text-purple card2">
                <th class="up2 text-center card2">No</th>
                <th class="up2 text-center card2">Chinese Character</th>
                <th class="up2 text-center card2">Pinyin</th>
                <th class="up2 text-center card2">Translation Word</th>
                <th class="up2 text-center card2">Audio</th>
              </tr>

            <?php
            for($i=1; $row1 = $sql1->fetch(); $i++){?>
                <tr class="up2 text-purple card2">
                  <td class="text-center"><?php echo $i;?>
                  <td class="text-center"><p class="title-learn text-center" style="padding-left:10px;"><b><?php echo $row1['c_word']; ?></b></p></td>
                  <td class="text-center"><p style="padding-left:10px;"><?php echo $row1['p_word']; ?></p></td>
                  <td class="text-center"><p style="padding-left:10px;"><?php echo $row1['e_word']; ?></p></td>
                  <td class="text-center"><audio controls>
                    <source src="<?php echo $row1['audio']; ?>" type="<?php echo $row1['type']; ?>">
                    Your browser does not support the audio element.
                  </audio></td>

                </tr>
            <?php }
                echo "</table>";
                echo '<br><br>';
            ?>


            <?php
                if($row['detail']!='')
                {
            ?>
            <p class="t-w"><strong>Explaination Chapter</strong></p>
            <br>
            <p><?php echo $row['detail']; ?></p>
            <p>&nbsp;</p><p>&nbsp;</p>
            <?php
                }
            ?>


            <?php
                foreach ($row2 as $try1)
                {
            ?>
            <p>&nbsp;</p><p>&nbsp;</p>
            <p class="t-w"><strong>Document to download</strong></p>
              <a href="<?php echo $try1['media']; ?>" download>
                <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft up2 delay-06s">
                  <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up2 text-purple card2">
                    <div style="width:20%;float:left;"><img src="img/folder.png" width="40"></div>
                    <p style="width:80%;padding-left:10px;float:right" ><b><?php echo $try1['name']; ?></b></p>
                    </div>
                </div>
              </a>
            <?php
                }
            ?>


      </div>
    </div>

  </div>
  </div>
</section>

<section class="kosong ad-margin">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft delay-06s up1 text-purple" style="">
        <div class="form">
          <a href="chapter-admin.php"><input class="input-btn" name="submit" type="submit" value="Back" style="width:100%;background:#ffa248"></a>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>
    </div>
</section>



<?php include("php/footer-admin.php"); ?>
