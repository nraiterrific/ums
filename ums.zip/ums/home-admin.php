<?php

include("php/header-admin.php");

?>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>University of Malaysia Sabah</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;">
  <div class="client_logos"><!--client_logos-->
    <div class="container">
      <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-0 col-xs-0">
        </div>
     	  <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12" >
          <h3>Hi <strong><?php echo $_SESSION['sess_adminname']; ?></strong>, are you ready ? </h3>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" >
          <a href="#service"><input class="input-btn" name="submit" type="submit" value="Let's start now!" style="width:100%"></a>
        </div>
        <div class="col-lg-2 col-md-2 col-sm-0 col-xs-0"  >
        </div>
      </div>


    </div>
  </div>
</section>


<!--Service-->
<section  id="service">
  <div class="container">
    <div class="service_wrapper">
      <div class="row">
        <div class="col-lg-4">
          <div class="service_block">
            <div class="delay-03s animated wow  zoomIn"><img src="img/brainstorm.png" alt="logo" width="80"></div>
            <h3 class="animated fadeInUp wow">Learn Topic</h3>
            <a href="chapter-admin.php"><input class="input-btn" name="submit" type="submit" value="Learn" style="width:100%"></a>
          </div>
        </div>
        <div class="col-lg-4 ">
          <div class="service_block">
            <div class="delay-03s animated wow zoomIn"><img src="img/question.png" alt="logo" width="80"></div>
            <h3 class="animated fadeInUp wow">Ask All Quizzes</h3>
            <a href="quiz.php"><input class="input-btn" name="submit" type="submit" value="Quizzes" style="width:100%"></a>
          </div>
        </div>
        <div class="col-lg-4 ">
          <div class="service_block">
            <div class="icon3  delay-03s animated wow zoomIn"><img src="img/scholarship.png" alt="logo" width="80"></div>
            <h3 class="animated fadeInUp wow">See Your Results</h3>
            <a href="result-admin.php"><input class="input-btn" name="submit" type="submit" value="Results" style="width:100%"></a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
<!--Service-->

<?php include("php/footer-admin.php"); ?>
