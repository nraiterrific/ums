<?php
session_start();
include("connection.php");
?>
<?php
$msg = "";
if(isset($_POST['submit'])) {
  $username = trim($_POST['username']);
  $password = trim($_POST['password']);
  if($username != "" && $password != "") {
    try {
      $query = "select * from `tb_admin` where `username`=:username and `password`=:password";
      $stmt = $conn->prepare($query);
      $stmt->bindParam('username', $username, PDO::PARAM_STR);
      $stmt->bindValue('password', $password, PDO::PARAM_STR);
      $stmt->execute();
      $count = $stmt->rowCount();
      $row   = $stmt->fetch(PDO::FETCH_ASSOC);
      if($count == 1 && !empty($row)) {
        /******************** Your code ***********************/
        $_SESSION['sess_admin_id']   = $row['id'];
        $_SESSION['sess_admin_name'] = $row['username'];
        $_SESSION['sess_adminname'] = $row['name'];
        $_SESSION['sess_admingetID'] = $row['admin_id'];
        header("location:home-admin.php");

      } else {
        $msg = "Invalid username and password!";
        echo '<script type="text/javascript">alert("'.$msg.'");</script>';
      }
    } catch (PDOException $e) {
      echo "Error : ".$e->getMessage();
    }
  } else {
    $msg = "Both fields are required!";
    echo '<script type="text/javascript">alert("'.$msg.'");</script>';
  }
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, maximum-scale=1">
<title>UMS MANDARIN</title>
<link rel="icon" href="favicon.png" type="image/png">
<link href="css/custom.css" rel="stylesheet" type="text/css">
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">


</head>
<body style="background-color:#8fc24b;">

<section id="aboutUs"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>

      <div class="col-lg-8 col-md-8 col-sm-10 wow fadeInLeft delay-06s up1 text-purple card up1">

        <form method="post" class="form">
          <center><h4>Login</h4>
            <div class="zoomIn wow animated" >
              <center><img src="img/scholarship.png" width="100"/>
              <br><br>
              <h4>UMS <strong>MANDARIN</strong></h4></center>
            </div>
          <h4>Welcome back! Login to access the UMS Mandarin.<br><br><br></center>
          <label class="">Username</label>
          <input class="input-text2" type="text" name="username" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" required>

          <label class="">Password</label>
          <input class="input-text2" type="password" name="password" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" required>
          <br>

          <input class="input-btn" type="submit" name="submit" value="Sign in" style="width:100%">
        </form>
        <BR><BR>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>
    </div>

  </div>
  </div>
</section>


<script type="text/javascript" src="js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
<script type="text/javascript" src="js/jquery.nav.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.isotope.js"></script>
<script type="text/javascript" src="js/wow.js"></script>
<script type="text/javascript" src="js/custom.js"></script>

</body>
</html>
