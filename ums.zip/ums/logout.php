<?php
session_start();
$_SESSION['sess_admin_id'] = "";
$_SESSION['sess_admin_name'] = "";
$_SESSION['sess_adminname'] = "";
if(empty($_SESSION['sess_admin_id'])) header("location: login-admin.php");
?>
