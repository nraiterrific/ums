<?php
session_start();
if(isset($_SESSION['sess_admin_id']) && $_SESSION['sess_admin_id'] != "") {
} else {
  header('location:login-admin.php');
}

require "connection.php";
?>

<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, maximum-scale=1">
  <title>UMS MANDARIN</title>
  <link href="css/custom.css" rel="stylesheet" type="text/css">
  <link rel="icon" href="favicon.png" type="image/png">
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <link href="css/font-awesome.css" rel="stylesheet" type="text/css">
  <link href="css/animate.css" rel="stylesheet" type="text/css">

</head>
<body>

<!--Header_section-->
<header id="header_wrapper" style="border-bottom:3px solid #ffa248">
  <div class="container">
    <div class="header_box">
      <!--<div class="logo">
        <a href="#">
          <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
          <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
          <img src="img/question.png" alt="logo" width="60">
        </a>
      </div>-->
	  <nav class="navbar navbar-inverse" role="navigation" >
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav">
          <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
        </button>
        </div>
	    <div id="main-nav" class="collapse navbar-collapse navStyle">
			<ul class="nav navbar-nav" id="mainNav">
			  <li><a href="home-admin.php" class="scroll-link">Home</a></li>
        <li><a href="chapter-admin.php" class="scroll-link">Chapter</a></li>
			  <li><a href="quiz.php" class="scroll-link">Quizes</a></li>
        <li><a href="question.php" class="scroll-link">Question</a></li>
			  <li><a href="result-admin.php" class="scroll-link">Results</a></li>
			  <li><a href="student-admin.php" class="scroll-link">Students</a></li>
			  <li><a href="profile-admin.php" class="scroll-link">Profile</a></li>
			  <li><a href="logout.php" class="scroll-link" style="background:#392560;color:#fff">Logout</a></li>
			</ul>
      </div>
	 </nav>
    </div>
  </div>
</header>
<!--Header_section-->
