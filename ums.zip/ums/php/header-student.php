<?php
session_start();
if(isset($_SESSION['sess_user_id']) && $_SESSION['sess_user_id'] != "") {
} else {
  header('location:index.php');
}

require "connection.php";
?>

<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, maximum-scale=1">
  <title>UMS MANDARIN</title>
  <link href="css/custom.css" rel="stylesheet" type="text/css">
  <link rel="icon" href="favicon.png" type="image/png">
  <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <link href="css/font-awesome.css" rel="stylesheet" type="text/css">
  <link href="css/animate.css" rel="stylesheet" type="text/css">



</head>
<body>

<!--Header_section-->
<header id="header_wrapper" style="border-bottom:3px solid #ffa248">
  <div class="container">
    <div class="header_box">
      <!--<div class="logo">
        <a href="#">
          <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
          <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
          <img src="img/question.png" alt="logo" width="60">
        </a>
      </div>-->
	  <nav class="navbar navbar-inverse" role="navigation">
      <div class="navbar-header">
        <button type="button" id="nav-toggle" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav">
          <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
        </button>
        </div>
	    <div id="main-nav" class="collapse navbar-collapse navStyle">
			<ul class="nav navbar-nav" id="mainNav">
			  <li><a href="home-student.php" class="scroll-link">Home</a></li>
        <li><a href="chapter-student.php" class="scroll-link">Chapter</a></li>
			  <li><a href="quiz-student.php" class="scroll-link">Quizzes</a></li>
			  <li><a href="result-view-student.php" class="scroll-link">Results</a></li>
			  <li><a href="profile-student.php" class="scroll-link">Profile</a></li>
			  <li><a href="logout-student.php" class="scroll-link" style="background:#392560;color:#fff">Logout</a></li>
			</ul>
      </div>
	 </nav>
    </div>
  </div>
</header>
<!--Header_section-->
