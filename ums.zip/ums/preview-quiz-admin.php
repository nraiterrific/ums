<?php

include("php/header-admin.php");

?>

<?php

  $get_id=$_GET['tb_quiz_modul'];

  $sql = $conn ->prepare("SELECT * FROM tb_quiz_modul WHERE id=$get_id");
  $sql ->execute();
  for($i=0; $row2 = $sql->fetch(); $i++)
  {
    $id = $row2['id'];
    $id2 = $row2['quiz_id'];
?>
<!--Hero_Section-->
<section id="hero_section" class="top_cont_outer" style="">
  <div class="hero_wrapper">
    <div class="container">
      <div class="hero_section">
        <div class="row">

          <div class="col-lg-3 col-sm-0"></div>

          <center>
            <div class="col-lg-6 col-sm-12 card s-card-p" >
            <img src="img/quiz.png" width="200"><br><BR>
            <h2 class="text-purple size-h2">Are you <strong>ready </strong>?</h2>

              <div class="row" style="border-top:1px solid #ccc; width:90%;">
                <div class="col-lg-12 col-sm-0">
                  <br><BR>
                    <h5 class="text-purple size-h5 text-left" style="text-transform:none;"><?php echo $row2['description']; ?></h5><br>
                    <h3 class="text-purple text-left">Title: <?php echo $row2['title']; ?></h3>
                    <h3 class="text-purple text-left">Estimated Time: <?php echo $row2['quiz_time']; ?> minutes</h3><br>

                  <a href="quiz-start.php<?php echo '?tb_question='.$id2; ?>"><input class="input-btn" name="submit" type="submit" value="Start" style=""></a>
                </div>
              </div>

            </div>
          </center>

          <div class="col-lg-3 col-sm-0 wow fadeInLeft delay-06s up1"></div>

        </div>

      </div>
    </div>
  </div>
</section>

<?php } ?>
<!--Hero_Section-->



<?php include("php/footer-admin.php"); ?>
