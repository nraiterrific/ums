<?php
include("php/header-student.php");
?>
<?php

$get_id=$_GET['tb_student'];

  try{
    if(isset($_POST['submit'])) {

        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $password = $_POST['password'];
        $new_pass =$_POST['new_pass'];
        $re_pass =$_POST['re_pass'];

        $query = "SELECT * FROM tb_student WHERE id='$get_id'";

        $sql2 = $conn->query($query);
        $result=$sql2->fetchAll(PDO::FETCH_ASSOC);

        print_r($result);

        foreach($result as $row2) {

          $id=$row2['id'];
          $passwordb=$row2['password'];

          if(!$sql2)
          {
            echo "ERROR, Unexisted User";
          }
          else if($passwordb!=$password)
          {
            ?> <script>
            alert('password dont match');
            window.location.href='profile-password-student.php<?php echo '?tb_student='.$id; ?>';
            </script> <?php
          }
          else if($password==$row2['password'])
          {
            if($new_pass==$re_pass)
            {
              $sql = "UPDATE tb_student SET password=:password, new_pass=:new_pass, re_pass=:re_pass WHERE id='$get_id'";

              $stmt = $conn->prepare($sql);
              $stmt -> bindParam (":password", $new_pass, PDO::PARAM_STR);
              $stmt -> bindParam (":new_pass", $new_pass, PDO::PARAM_STR);
              $stmt -> bindParam (":re_pass", $re_pass, PDO::PARAM_STR);
              $stmt->execute();
                      ?>
                      <script>
                      alert('Password changed');
                      window.location.href='profile-student.php';
                      </script> <?php
            }
            else if ($new_pass!=$re_pass)
            {
              ?>
              <script>
              alert('Wrong match!');
              window.location.href='profile-password-student.php<?php echo '?tb_student='.$id; ?>';
              </script> <?php
            }
            else
            {
              ?> <script>
              alert('Error, new password and confirm password must be the same');
              window.location.href='profile-student.php';
              </script> <?php
            }
          }
        }//foreach
      }//if submit
    } catch(PDOException $e){
        die("ERROR: Could not able to execute $sql2. " . $e->getMessage());
    }

    /***********************************************************************/

?>

<style>
input:read-only { background: #bbbbbb; }
}

</style>

<!--Hero_Section-->
<section id="hero_section" class="top_cont_outer" style="background-image: url(img/bg-3.jpg); background-position: center; background-repeat: no-repeat;background-size: cover;">
  <div class="hero_wrapper">
    <div class="container">
      <div class="hero_section">
        <div class="row">

          <div class="col-lg-3 col-sm-0"></div>

          <center>
            <div class="col-lg-6 col-sm-12 card s-card-p" >
            <img src="img/student.png" width="200"><br><BR>
            <h2 class="text-purple size-h2">Update Password</h2>
            <h5 class="text-purple size-h5">as Student Role</h5>
            <br>

              <div class="row" style="border-top:1px solid #ccc; width:90%;">
                <div class="col-lg-12 col-sm-0">
                  <br>

                    <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

                      <label class="text-left text-purple" style="float:left;">Current Password</label>
                      <input class="input-text3" type="password" name="password" value="" required>

                      <label class="text-left text-purple" style="float:left;">New Password</label>
                      <input class="input-text3" type="password" name="new_pass" value="" required>

                      <label class="text-left text-purple" style="float:left;">Re-type New Password</label>
                      <input class="input-text3" type="password" id="re_pass" name="re_pass" value="">
                      <!--<p id="usercheck" class="add-up1 help-block" style="color:red;font-weight: bold;margin-top:-15px;"></p><br>-->

                      <!--<label class="">Confirm Password</label>
                      <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

                      <input class="input-btn" name="submit" type="submit" value="Update" style="width:100%;">
                    </form>

                </div>
              </div>

            </div>
          </center>

          <div class="col-lg-3 col-sm-0 wow fadeInLeft delay-06s up1"></div>

        </div>

      </div>
    </div>
  </div>
</section>



<?php include("php/footer-student.php"); ?>
