<?php
error_reporting(0);
include("php/header-student.php");

?>
<?php
  $get_id=$_GET['tb_student'];

  try{
      if(isset($_POST['submit'])) {

        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          $sql = "UPDATE tb_student SET name=:name, matrix=:matrix, username=:username WHERE id=$get_id";

          $stmt = $conn->prepare($sql);
          $stmt -> bindParam (":name", $_POST['name'], PDO::PARAM_STR);
          $stmt -> bindParam (":matrix", $_POST['matrix'], PDO::PARAM_STR);
          $stmt -> bindParam (":username", $_POST['username'], PDO::PARAM_STR);

          $stmt->execute();
          ?> <script>
          alert('Successfully updated');
          </script> <?php
          echo "<script>window.location='profile-student.php'</script>";

      }
    } catch(PDOException $e){
        die("ERROR: Could not able to execute $sql2. " . $e->getMessage());
    }

    /***********************************************************************/
    $sql2 = $conn ->prepare("SELECT * FROM tb_student WHERE id='$get_id'");
    $sql2 ->execute();
    for($i=0; $row2 = $sql2->fetch(); $i++)
    {
      $id = $row2['id'];
?>

<style>
input:read-only { background: #bbbbbb; }
}

</style>

<!--Hero_Section-->
<section id="hero_section" class="top_cont_outer" >
  <div class="hero_wrapper">
    <div class="container">
      <div class="hero_section">
        <div class="row">

          <div class="col-lg-3 col-sm-0"></div>

          <center>
            <div class="col-lg-6 col-sm-12 card s-card-p" >
            <img src="img/student.png" width="200"><br><BR>
            <h2 class="text-purple size-h2">Update data</h2>
            <h5 class="text-purple size-h5">as Student Role</h5>
            <br>

              <div class="row" style="border-top:1px solid #ccc; width:90%;">
                <div class="col-lg-12 col-sm-0">
                  <br>

                    <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

                      <label class="text-left text-purple" style="float:left;">Name</label>
                      <input class="input-text3" type="text" name="name" value="<?php echo $row2['name']; ?>" required>

                      <label class="text-left text-purple" style="float:left;">Matrix</label>
                      <input class="input-text3" type="text" name="matrix" value="<?php echo $row2['matrix']; ?>" required>

                      <label class="text-left text-purple" style="float:left;">Username</label>
                      <input class="input-text3" type="text" id="username" name="username" value="<?php echo $row2['username']; ?>" readonly >
                      <!--<p id="usercheck" class="add-up1 help-block" style="color:red;font-weight: bold;margin-top:-15px;"></p><br>-->

                      <!--<label class="">Confirm Password</label>
                      <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

                      <input class="input-btn" name="submit" type="submit" value="Update" style="width:100%;">
                    </form>

                </div>
              </div>

            </div>
          </center>

          <div class="col-lg-3 col-sm-0 wow fadeInLeft delay-06s up1"></div>

        </div>

      </div>
    </div>
  </div>
</section>

<?php } ?>
<!--Hero_Section-->


<?php include("php/footer-student.php"); ?>
