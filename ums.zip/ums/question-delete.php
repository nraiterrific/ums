

    <?php
    require_once('connection.php');

    $get_id=$_GET['tb_question'];

    $sql2 = $conn ->prepare("SELECT * FROM tb_question WHERE id='$get_id'");
	  $sql2 ->execute();
	  for($i=0; $row2 = $sql2->fetch(); $i++)
	  {
      $quest_id = $row2['quest_id'];
    // sql to delete a record
    $sql = "Delete from tb_question where id = '$get_id'";
    $conn->exec($sql);

    $sql22 = "Delete from tb_choices where quest_id = '$quest_id'";
    $conn->exec($sql22);

    $sql22 = "Delete from tb_question_media where quest_id = '$quest_id'";
    $conn->exec($sql22);

    echo "<script>alert('Successfully deleted !'); window.location='question.php'</script>";


  }?>
