

    <?php
    require_once('connection.php');

    $get_id=$_GET['tb_question'];

    // sql to delete a record
    $sql2 = $conn ->prepare("SELECT * FROM tb_question WHERE id='$get_id'");
    $sql2 ->execute();
    for($i=0; $row2 = $sql2->fetch(); $i++)
    {

      $id_chap=$row2['category'];

      $sql = "Delete from tb_question where id = '$get_id'";

      // use exec() because no results are returned
      $conn->exec($sql); ?>

      <script>
      alert('Successfully deleted !');
      window.location.href='quiz-create1.php<?php echo '?tb_quiz_modul='.$id_chap; ?>';
      </script>

    <?php } ?>
