
    <?php
    require_once('connection.php');

    $get_id=$_GET['tb_question_media'];

    // sql to delete a record
		$sql2 = $conn ->prepare("SELECT * FROM tb_question_media WHERE id='$get_id'");
	  $sql2 ->execute();
	  for($i=0; $row2 = $sql2->fetch(); $i++)
	  {

			$id_chap=$row2['quest_id'];

	    $sql = "Delete from tb_question_media where id = '$get_id'";

			// use exec() because no results are returned
			$conn->exec($sql); ?>


			<script>
			alert('Successfully deleted !');
			window.location.href='question-media-update.php<?php echo '?tb_question='.$id_chap; ?>';
			</script>

		<?php } ?>
