<?php

include("php/header-admin.php") ;

$get_id=$_GET['tb_question'];

    if(isset($_POST['submit'])) {

      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Loop all files
        for($io=0; $io < count($_FILES['files']['name']); $io++){
            // File name
            $filetemp = $_FILES['files']['tmp_name'][$io];
            $filename = $_FILES['files']['name'][$io];
            $filetype = $_FILES['files']['type'][$io];
            $filepath = "upload/content-chapter/".$filename;

            move_uploaded_file($filetemp,$filepath);

            // Prepared statement
            $query = "INSERT INTO tb_question_media (name,media,type,quest_id) VALUES('$filename','$filepath','$filetype','$get_id')";
            $statement = $conn->prepare($query);
            $statement->execute();
          }
      }


?>

<style>
input:read-only { background: #bbbbbb; }
}
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Update Question Media Files</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>

    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card">

        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <label>Upload Media (Video, Documents and Photos)</label>
          <input type="file" class="input-text3" name="files[]" multiple>

          <label class="">In Question ID</label>
          <input type="text" class="input-text3"  value="<?php echo $get_id; ?>" name="quest_id" readonly>

          <br><Br>
          <center><input class="input-btn" name="submit" type="submit" value="Update" style="width:80%;"></center>
        </form>
        <br><Br>
      </div>

    </div>

  </div>
  </div>
</section>


<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

      <div class="row" style="width:100%; height:auto; margin-top:50px;">

        <?php
          $sql2 = $conn ->prepare("SELECT * FROM tb_question_media WHERE quest_id='$get_id'");
          $sql2 ->execute();

              for($i=0; $row2 = $sql2->fetch(); $i++)
              {
                $id34 = $row2['id']
                ?>
                <div class=" col-lg-4 col-md-4 col-sm-6" style="">
                  <div class="box-ppp" >
                    <img src="<?php echo $row2['media']; ?>" />
                    <div style="float:left;"><?php echo $row2['name']; ?></div>
                    <div class="d-bgt" style="float:right;"><a href="question-media-delete.php<?php echo '?tb_question_media='.$id34 ?>" style="color:#FFF;">Delete</a></div>
                  </div>
                </div>
            <?php } ?>


      </div>
    </div>
  </div>
</section>


<?php include("php/footer-admin.php"); ?>
