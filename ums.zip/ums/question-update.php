<?php
define("ROW_PER_PAGE",9);
include("php/header-admin.php") ;

    $get_id=$_GET['tb_question'];

    if(isset($_POST['submit'])) {

      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      // Prepared statement
      $sql = "UPDATE tb_question SET quest=:quest,op1=:op1,op2=:op2,op3=:op3,op4=:op4,is_right=:is_right
              WHERE id=$get_id";

      $statement = $conn->prepare($query);
      $stmt = $conn->prepare($sql);

      $stmt -> bindParam (":quest", $_POST['quest'], PDO::PARAM_STR);
      $stmt -> bindParam (":op1", $_POST['op1'], PDO::PARAM_STR);
      $stmt -> bindParam (":op2", $_POST['op2'], PDO::PARAM_STR);
      $stmt -> bindParam (":op3", $_POST['op3'], PDO::PARAM_STR);
      $stmt -> bindParam (":op4", $_POST['op4'], PDO::PARAM_STR);
      $stmt -> bindParam (":is_right", $_POST['is_right'], PDO::PARAM_STR);

      $stmt->execute();
      ?>
      <script>
      alert('Successfully updated !!');
      </script>
      <?php
      echo "<script>window.location='question.php'</script>";
    }

    $sql2 = $conn ->prepare("SELECT * FROM tb_question WHERE id='$get_id';");
    $sql2 ->execute();
    for($i=0; $row2 = $sql2->fetch(); $i++)
    {
      $category=$row2['quest_id'];

      $sql21 = $conn ->prepare("SELECT * FROM tb_choices WHERE quest_id='$category';");
      $sql21 ->execute();





?>

<style>
input:read-only { background: #bbbbbb; }
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Update Question</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card" >
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <br>
            <a class="text-purple" href="question-media-update.php<?php echo '?tb_question='.$category; ?>"><div class="btn-icon vtew" style="float:right;text-align:center;background:#ffa248;">
              <i class="i-con22 fa fa-refresh" style="font-size:25px;float:left;"></i><center><span style="float:right;font-size:20px;"><strong>Media</strong></span></center></div>
            </a>
          </p>

          <br>

          <div class="row">

            <div class="col-lg-12 col-md-12 col-sm-12">
              <label class="">Question</label>
              <input class="input-text3" type="text" name="quest" value="<?php echo $row2['quest']; ?>" >
            </div>

          </div>

          <div class="row">
            <?php

            for($i1=1; $row21 = $sql21->fetch(); $i1++)
            {
              $choices = $row21['choices'];

             ?>
            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Option <?php echo $i1; ?></label>
              <input class="input-text3" type="text" name="choice" value="<?php echo $choices; ?>" >
            </div>

            <?php }

            $sql211 = $conn ->prepare("SELECT * FROM tb_choices WHERE is_right='1' AND quest_id='$category';");
            $sql211 ->execute();


            for($i11=1; $row211 = $sql211->fetch(); $i11++)
            {
              $anss=$row211['choices'];
            ?>

            <div class="col-lg-12 col-md-12 col-sm-12">
              <label class="">Correct Answer</label>
              <input class="input-text3" type="text" name="is_right" value="<?php echo $anss; ?>" >
            </div>

            <?php } ?>

          </div>

          <input id="btn-add" class="t-b-t" name="submit" type="submit" value="Update">


          <br><br><br>
        </form>
      </div>

    </div>

  </div>
  </div>
</section>

<?php } ?>

<?php include("php/footer-admin.php"); ?>
