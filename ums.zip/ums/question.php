<?php
define("ROW_PER_PAGE",9);
include("php/header-admin.php") ;
//error_reporting(0);


    if(isset($_POST['submit'])) {

      $quest_id =uniqid();
      $quest=$_POST['quest'];
      $answer = $_POST['answer'];
      $choices = array();
      $choices[1] = $_POST['choices1'];
      $choices[2] = $_POST['choices2'];
      $choices[3] = $_POST['choices3'];
      $choices[4] = $_POST['choices4'];
      $chapter = $_POST['chapter'];

      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      //if(!$message)
      //{
        $query = "INSERT INTO tb_question (quest_id,quest,chapter) VALUES('$quest_id','$quest','$chapter')";
        $statement = $conn->prepare($query);
        $statement->execute();

        //Validate INSERT
        if($statement){
          foreach($choices as $choices=>$value){
            if($value !=''){
              if($answer == $choices){
                $is_right =1;
              }else {
                $is_right =0;
              }
              $query1="INSERT INTO tb_choices(choices, is_right,quest_id)
                      VALUES('$value','$is_right','$quest_id')";
              $statement1 = $conn->prepare($query1);
              $statement1->execute();
            }
          }
        }

    } //submit (insert question)


    $sql = $conn ->prepare("SELECT * FROM tb_question WHERE category=' ';");
    $sql ->execute();
    $row2 = $sql ->fetchAll();

?>

<style>
input:read-only { background: #bbbbbb; }

</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Create Question Bank</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card" >
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <br>
          <p class="t-w"><strong>Bank Question</strong></p>
          <br>

          <div class="row">

            <div class="col-lg-12 col-md-12 col-sm-12">
              <label class="">Question</label>
              <input class="input-text3" type="text" name="quest" value="" required>
            </div>

          </div>

          <div class="row">

            <div class="col-lg-6 col-md-6 col-sm-12">

              <label class="">Option 1</label>
              <input class="input-text3" type="text" name="choices1" value="" required>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">

              <label class="">Option 2</label>
              <input class="input-text3" type="text" name="choices2" value="" required>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">

              <label class="">Option 3</label>
              <input class="input-text3" type="text" name="choices3" value="" >
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">

              <label class="">Option 4</label>
              <input class="input-text3" type="text" name="choices4" value="" >
            </div>

            <div class="col-lg-6 col-md-6 col-sm-6">

              <label class="">Correct choice number</label>
              <input class="input-text3" type="number" name="answer" max="4" value="" required>
            </div>

            <div class="col-lg-6 col-md-6 col-sm-12">

              <label class="">Chapter Category</label>
              <input class="input-text3" type="number" name="chapter" value="" required>
            </div>


          </div>

          <input id="btn-add" class="t-b-t" name="submit" type="submit" value="Add Question">


          <br><br><br>
        </form>
      </div>

    </div>

  </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
  <div class="inner_wrapper">
    <div class="container">

      <div class="row" ><br><br><br>
        <h3 class="text-purple text-left jjs" style="font-size:25px;margin-left:15px"><u><strong>List of Bank Question</strong></u></h3><br>

        ?>

            <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft up2 delay-06s">
              <div id="col2" class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up2 text-purple card" style="padding:8px;">

                <table border='1' style="width:100%;">
                  <tr class="up2 text-purple card2">
                    <th class="up2 text-center card2">No</th>
                    <th class="up2 text-center card2">Question</th>
                    <th class="up2 text-center card2">Answer</th>
                    <th class="up2 text-center card2">Chapter</th>
                    <th class="up2 text-center card2">Action</th>
                  </tr>

                <?php
                $z = 1;
                foreach ($row2 as $rows){

                      $id666 = $rows['id'];
                      $category = $rows['quest_id'];

                      $sql21 = $conn ->prepare("SELECT * FROM tb_choices WHERE quest_id='$category';");
                      $sql21 ->execute();
                      $row21 = $sql21->fetch();

                      $sql211 = $conn ->prepare("SELECT * FROM tb_choices WHERE is_right='1' AND quest_id='$category';");
                      $sql211 ->execute();
                      $row211 = $sql211->fetch();

                      ?>

                    <tr class="up2 text-purple card2">
                      <td class="text-center"><?php echo $z;?>
                      <td class="text-center"><p class="title-learn text-center" style="padding-left:10px;"><b><?php echo $rows['quest']; ?></b></p></td>
                      <td class="text-center"><p style="padding-left:10px;"><?php echo $row211['choices']; ?></p></td>
                      <td class="text-center"><p style="padding-left:10px;"><?php echo $rows['chapter']; ?></p></td>
                      <td class="text-center">
                        <a class="text-purple" href="question-delete.php<?php echo '?tb_question='.$id666; ?>" onclick="return confirm('Are you sure want to delete?')">
                          <div class="btn-icon3 aa11" style="display:block">
                          <center>
                            <i class="i-con22 fa fa-remove" style="font-size:25px;"></i>
                          </center>
                        </div>
                        </a>
                      </td>

                    </tr>
                <?php $z=$z+1; }
                    echo "</table>";
                    echo '<br><br>';

                ?>

              </div>
            </div>

      </div>

    </div>
  </div>
</section>


<?php include("php/footer-admin.php"); ?>
