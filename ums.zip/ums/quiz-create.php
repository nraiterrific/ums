<?php
define("ROW_PER_PAGE",9);
include("php/header-admin.php") ;
error_reporting(0);


    if(isset($_POST['submit'])) {

      $quiz_id =uniqid();
      $title = $_POST['title'];
      $desc = $_POST['desc'];
      $time = $_POST['quiz_time'];

      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

      $query = "INSERT INTO tb_quiz_modul (quiz_id,title,description,quiz_time)
                VALUES('$quiz_id','$title','$desc','$time')";

      $statement = $conn->prepare($query);
      $statement->execute();

      ?>
      <script>
      alert('Successfully added. Please proceed to the create question');
      window.location.href='quiz-create1.php<?php echo '?tb_quiz_modul='.$quiz_id; ?>';
      </script>
      <?php


    } //submit (insert question)


?>

<style>
input:read-only { background: #bbbbbb; }
}
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Create Quiz Module</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card" >
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <br>
          <p class="t-w"><strong>Quiz Modul</strong></p>
          <br>

          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Title</label>
              <input class="input-text3" type="text" name="title" value="" required>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
              <label class="">Set time</label>
              <select name="quiz_time" class="input-text3">
                <option value="15">15 min</option>
                <option value="25">25 min</option>
                <option value="30">30 min</option>
                <option value="45">45 min</option>
                <option value="50">50 min</option>
                <option value="60">60 min</option>
              </select>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12">
              <label class="">Description</label>
              <textarea class="input-text3 text-area" name="desc" cols="5" rows="5" maxlength="1000" style="" ></textarea>
            </div>
          </div>

          <input id="btn-add" class="t-b-t" name="submit" type="submit" value="Proceed">

          <br><br><br>
        </form>
      </div>

    </div>

  </div>
  </div>
</section>


<br><br><br>

<?php include("php/footer-admin.php"); ?>
