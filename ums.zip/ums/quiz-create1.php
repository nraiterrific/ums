<?php
define("ROW_PER_PAGE",9);
include("php/header-admin.php") ;
error_reporting(0);


    $get_id=$_GET['tb_quiz_modul'];

    /**********************************************************************/
    if(isset($_POST['update_num'])) {

      $sql21 = $conn ->prepare("SELECT * FROM tb_question WHERE category='$get_id'");
      $sql21 ->execute();
      //get result of tb_modul
      $sql33 = "Delete from tb_question where category='$get_id'";
      $conn->exec($sql33);

      $num=1;

      for($i2=1; $row2 = $sql21->fetch(); $i2++)
      {

        $quest_id =$row2['quest_id'];
        $quest=$row2['quest'];

        $query = "INSERT INTO tb_question (quest_id,quest,category,quest_num)
                  VALUES('$quest_id','$quest','$get_id','$num')";

        $statement = $conn->prepare($query);
        $statement->execute();
        $num++;

        ?>
        <script>
  			alert('Successfully inserted.');
  			window.location.href='quiz.php';
  			</script>
        <?php
      }

    }

    /**********************************************************************/
    $s = $conn ->prepare("SELECT * FROM tb_question WHERE category='$get_id'");
    $s ->execute();

?>

<style>
input:read-only { background: #bbbbbb; }
}
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Create Quiz Module</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card" >
        <div method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <br><br>
          <p class="t-w"><strong>Create Question</strong></p>
          <br>

          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="aa14">
                <br><br>
                <center><label>Pick from Question Bank</label></center>
                <p>
                  <a class="aa15" href="quiz-question-bank.php<?php echo '?tb_quiz_modul='.$get_id; ?>">
                    <center><input id="btn-add" class="btn-linkk text-center" style="cursor:pointer" value="Add Question"></center>
                  </a>
                </p>
                <br><br>
              </div>
            </div>
          </div>
          <br><br>
        </div>
      </div>

    </div>

  </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
  <div class="inner_wrapper">
    <div class="container">

      <div class="row" >

        <div class="col-lg-6 col-md-6 col-sm-0 col-xs-0">
        </div>


      </div>

      <div class="row" >
        <h3 class="text-purple text-left jjs" style="font-size:25px;margin-left:15px"><u><strong>List of Questions</strong></u></h3><br>

        <?php

        for($i=0; $row = $s->fetch(); $i++)
        {

          $id = $row['id'];
          $chapter_id = $row['category'];

        ?>

            <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft up2 delay-06s">
              <div id="col2" class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up2 text-purple card" style="padding:8px;">

                <a class="text-purple" href="question-delete1.php<?php echo '?tb_question='.$id; ?>" onclick="return confirm('Are you sure want to delete?')">
                    <div class="btn-icon3 aa11" style="display:block">
                    <center>
                      <i class="i-con22 fa fa-remove" style="font-size:25px;"></i>
                    </center>
                  </div>
                </a>
                  <br>
                  <h3 class=" aa12"><?php echo $row['quest_id']; ?></h3>
                  <h4 class="title-learn aa13" style="padding-left:10px;"><?php echo $row['quest']; ?></h4>
                  <h4 class="title-learn aa13" style="padding-left:10px;"><?php echo $row['is_right']; ?></h4><br>
              </div>
            </div>

        <?php
      }
      ?>

      </div>
    </div>
  </div>
</section>

<section class="kosong ad-margin">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft delay-06s up1 text-purple" style="">
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">
          <!--<a href="quiz.php"><input class="input-btn" name="update_num" type="submit" value="Sumbit" onclick="alert('Successfully added.');" style="width:100%;background:#ffa248"></a>-->
          <input class="input-btn" name="update_num" type="submit" value="Sumbit" style="width:100%;background:#ffa248">
        </form>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>
    </div>
</section>


<?php include("php/footer-admin.php"); ?>
