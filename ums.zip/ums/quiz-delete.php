

    <?php
    require_once('connection.php');

    $get_id=$_GET['tb_quiz_modul'];

    $sql2 = $conn ->prepare("SELECT * FROM tb_quiz_modul WHERE id='$get_id'");
	  $sql2 ->execute();
	  for($i=0; $row2 = $sql2->fetch(); $i++)
	  {
      $quiz_id = $row2['quiz_id'];
    // sql to delete a record
    $sql = "Delete from tb_quiz_modul where id = '$get_id'";
    $conn->exec($sql);

    $sql22 = "Delete from tb_choices where category = '$quiz_id'";
    $conn->exec($sql22);

    $sql22 = "Delete from tb_question_media where category = '$quiz_id'";
    $conn->exec($sql22);

    $sql22 = "Delete from tb_question where category = '$quiz_id'";
    $conn->exec($sql22);

    echo "<script>alert('Successfully deleted !'); window.location='quiz.php'</script>";


  }?>
