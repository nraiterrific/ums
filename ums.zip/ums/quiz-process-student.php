<?php

include "connection.php";
session_start();

    if($_POST) {

      //$user = $_SESSION['sess_admin_id'];  //admin id
      //$quiz_id = $_POST['quiz_id'];
      //$result_id =uniqid();

      $get_id=$_POST['id'];
      $quest_id = $_POST['quest_id'];
      $number = $_POST['number'];
      $time = $_POST['time'];
      $time_remaining =$_POST['time_remaining'];
      $score = $_POST['score'];
      $selected_choice = $_POST['choices'];
      $next=$number+1;
      //$time = $_POST['time'];

      //Get total number of questions
     $sql4 = "SELECT count(*) FROM tb_question WHERE category='$get_id'";
     $result4 = $conn->prepare($sql4);
     $result4->execute();
     $total = $result4->fetchColumn();

     //het the all questing according to get_id
     $sql21 = $conn ->prepare("SELECT * FROM tb_choices WHERE quest_id='$quest_id' AND is_right='1'");
     $sql21 ->execute();
     $row1 = $sql21->fetch();

     $choices = $row1['choices'];

     //het the all questing according to get_id
     $sql21q = $conn ->prepare("SELECT * FROM tb_quiz_modul WHERE quiz_id='$quest_id'");
     $sql21q ->execute();
     $row1q = $sql21q->fetch();

     $minustime = $row1q['quiz_time'];
     $converttime = $minustime*60;

      $newtime = time();

      $difference = $newtime - $time;
      $time_remaining = $time_remaining - $difference;

      if($time_remaining <=0){

        $user_id=$_SESSION['sess_usergetID'];
        $user_name = $_SESSION['sess_name'];
        $result_per = ($score/$total)*100;

        $qq = "INSERT INTO tb_result (user_id,quiz_id,result,result_per,name) VALUES('$user_id','$get_id','$score','$result_per','$user_name')";
        $statement = $conn->prepare($qq);
        $statement->execute();

        $sa = $conn ->prepare("SELECT * FROM tb_result WHERE user_id='$user_id' ORDER BY id DESC LIMIT 1");
        $sa ->execute();
        $rowsa = $sa->fetch();

        $category = $rowsa['id'];

        header("Location: quiz-result1-student.php?total=$total&score=$score&tb_result=".$category);

        exit();
      }



      if($choices == $selected_choice ){
        $score=$score+1;
      }

      if($number == $total){

        $user_id=$_SESSION['sess_usergetID'];
        $user_name = $_SESSION['sess_name'];
        $result_per = ($score/$total)*100;

        $qq = "INSERT INTO tb_result (user_id,quiz_id,result,result_per,name) VALUES('$user_id','$get_id','$score','$result_per','$user_name')";
        $statement = $conn->prepare($qq);
        $statement->execute();

        $sa = $conn ->prepare("SELECT * FROM tb_result WHERE user_id='$user_id' ORDER BY id DESC LIMIT 1");
        $sa ->execute();
        $rowsa = $sa->fetch();

        $category = $rowsa['id'];


        header("Location: quiz-result-student.php?total=$total&score=$score&tb_result=".$category);
        exit();
      }else {
              header("Location: quiz-start-student.php?time=$remindertime&time_remaining=$time_remaining&n=$next&tb_question=$get_id&score=".$score);
      }

    }

    /*if(isset($_POST['next'])) {

      $next=$number+1;
      $get_id=$_POST['id'];
      $quest_id = $_POST['quest_id'];
      $number = $_POST['number'];
      $score = $_POST['score'];
      header("Location: quiz-start.php?n=$next&tb_question=$get_id&score=".$score);

    }

    if(isset($_POST['back'])) {

      $next=$number-1;
      $get_id=$_POST['id'];
      $quest_id = $_POST['quest_id'];
      $number = $_POST['number'];
      $score = $_POST['score'];
      header("Location: quiz-start.php?n=$next&tb_question=$get_id&score=".$score);

    }*/


?>
