<?php
define("ROW_PER_PAGE",9);
include("php/header-admin.php") ;
error_reporting(0);

    //get category
    $get_id=$_GET['tb_result'];
    $total = (int) $_GET['total'];
    $score = (int) $_GET['score'];

    $sa = $conn ->prepare("SELECT * FROM tb_result WHERE id='$get_id'");
    $sa ->execute();

    for($i=0; $rowsa = $sa->fetch(); $i++){
      $percentage = $rowsa['result_per'];

?>

<style>
input:read-only { background: #bbbbbb; }
}
</style>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Result</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-2 col-md-2 col-sm-12" ></div>

      <div class="col-lg-8 col-md-8 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card" >
        <div method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <?php
                if($percentage >=50)
                {
                  ?>
                  <H2>Congratulation!<h2>
                    <h2 class="tgt">You pass the quiz</h2>
                    <h2 class="tgt">Score <strong><?php echo $score; ?></strong> out of <strong><?php echo $total; ?></strong></h2>
                    <h1 class="text-center"><strong><?php echo $percentage; ?>%</strong>
                  <?php
                }
                else if($percentage <50)
                {
                  ?>
                  <H2>Sorry!<h2>
                    <h2 class="tgt">You didn't pass the quiz</h2>
                    <h2 class="tgt">Score <strong><?php echo $score; ?></strong> out of <strong><?php echo $total; ?></strong></h2>
                    <h1 class="text-center"><strong><?php echo $percentage; ?>%</strong>
                  <?php
                }
              ?>
              <p>&nbsp;</p>
              <a href="chapter-admin.php"><center><input class="input-btn" name="submit" type="submit" value="Learn New Chapter" style="width:70%;background:#ffa248;"></center></a>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-12" ></div>

    </div>

  </div>
  </div>
</section>

<br><br><br><br><br><br><br><br><br>
<?php } include("php/footer-admin.php")?>
