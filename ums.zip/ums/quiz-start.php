<?php
include("php/header-admin.php");
error_reporting(0);
?>

<?php

    //Set question number
    $number = (int) $_GET['n'];
    if($number==0)
    { $number = '1';}

    //Set question number
    $score = (int) $_GET['score'];

    //get category
    $get_id=$_GET['tb_question'];

    //het the all questing according to get_id
    $sql21 = $conn ->prepare("SELECT * FROM tb_question WHERE category='$get_id' AND quest_num='$number' LIMIT 1");
    $sql21 ->execute();

     //Get total number of questions
    $sql4 = "SELECT count(*) FROM tb_question WHERE category='$get_id'";
    $result4 = $conn->prepare($sql4);
    $result4->execute();
    $number_of_rows = $result4->fetchColumn();


    //get tb_modul for display time
    $sql2 = $conn ->prepare("SELECT * FROM tb_quiz_modul WHERE quiz_id='$get_id'");
    $sql2 ->execute();
    //get result of tb_modul
    for($i=0; $row2 = $sql2->fetch(); $i++)
    {
      $vt = $row2['quiz_time'];

      //Set question number
      $time = (int) $_GET['time'];
      if($time==0)
      {
        $time = time();
        $_SESSION['time_started'] = $time;
      }

      $time_remaining = (int) $_GET['time_remaining'];
      if($time_remaining==0)
      {
        $time_remaining = $vt*60;
        $_SESSION['time_remaining'] = $time_remaining;
      }

?>

<section onload="f1()" id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;border-bottom:10px solid #392560;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Quiz: <?php echo $row2['title']; ?></h2>

    <!--/****************************************************************************************************************************/-->
    <h3 class="text-center design" id="quiz-time-left" style=""></h3><br><BR>

    <script type="text/javascript">
          var seconds = <?php echo $time_remaining; ?>;
          function secondPassed()
          {
              var minutes = Math.round((seconds - 30)/60);
              var remainingSeconds = seconds % 60;
              if (remainingSeconds < 10)
              {
                  remainingSeconds = "0" + remainingSeconds;
              }
              document.getElementById('quiz-time-left').innerHTML ="Time Left : " + minutes + ":" + remainingSeconds;

              if (seconds == 0 || seconds<0)
              {
                  clearInterval(countdownTimer);
              }
              else
              {
                  seconds--;
              }
          }
          var countdownTimer = setInterval('secondPassed()', 1000);
        </script>

      <!--/****************************************************************************************************************************/-->


    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>


<!--bannner-->

<section id="aboutUs" style="padding-top:70px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <br>
    <?php
      //get result of tb_question
      for($i1=$number; $row21 = $sql21->fetch();)
      {
        $quest_id = $row21['quest_id'];
        $c = $row21['category'];
    ?>

    <div class="row ad-b" style="margin:0px;">
      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>
      <div class="col-lg-8 col-md-8 col-sm-10 wow fadeInLeft delay-06s text-purple card " style="margin-bottom:30px;">
        <div class="row">
          <div class="col-lg-2 col-md-2 col-sm-12 orgg desk-v">
            <h3>QUESTION</h3>
            <centeR><h3><?php echo $i1; ?> <strong>/ <?php echo $number_of_rows; ?></strong></h3></centeR>
          </div>
          <div class="col-lg-10 col-md-10 col-sm-12">
            <h3 class="text-left text-purple txt"><?php echo $row21['quest'] ?></h3>
          </div>
          <div class="col-lg-12 col-md-12 col-sm-12">
            <br>
            <form method="post" action="quiz-process.php" name="quiz"  >

                  <ul class="choices">
                    <?php
                    //het the all questing according to get_id
                    $q = $conn ->prepare("SELECT * FROM tb_choices WHERE quest_id='$quest_id'");
                    $q ->execute();
                    for($p=0; $p1 = $q->fetch(); $p++)
                    {
                    ?>
                    <li><input name="choices" class="form-radio" type="radio" value="<?php echo $p1['choices']; ?>" required />
                      <span class="rtr"><?php echo $p1['choices']; ?></span>
                    </li>
                    <?php }   ?>
                  </ul>
          </div>
        </div>
        <!--<input id="btn-add" class="t-b-t aaa" name="next"  value=">" style="margin-left:5px;width:50px">
        <input id="btn-add" class="t-b-t aaa" name="back" value="<" style="width:50px">-->
      </div>
      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>
    </div>
    <?php $i1++; } ?>
      <input type="hidden" class="text-purple" name="number" value="<?php echo $number; ?>" />
      <input type="hidden" class="text-purple" name="quest_id" value="<?php echo $quest_id; ?>" />
      <input type="hidden" class="text-purple" name="id" value="<?php echo $get_id; ?>" />
      <input type="hidden" class="text-purple" name="score" value="<?php echo $score; ?>" />
      <input type="hidden" class="text-purple" name="time" value="<?php echo $time; ?>" />
      <input type="hidden" class="text-purple" name="time_remaining" value="<?php echo $time_remaining; ?>" />

      <center><input class="input-btn" name="submit" type="submit" value="SUBMIT" style="width:70%;background:#ffa248"></center>
    </form>

  </div>
  </div>
</section>


<br><br><br><br>

<?php include("php/footer-admin.php"); ?>
<?php } ?>
