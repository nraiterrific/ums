<?php
define("ROW_PER_PAGE",10);
include("php/header-student.php") ;
error_reporting(0);

$search_keyword = '';
if(!empty($_POST['search']['keyword'])) {
  $search_keyword = $_POST['search']['keyword'];
}
$sql = 'SELECT * FROM tb_quiz_modul WHERE title LIKE :keyword OR quiz_id LIKE :keyword ORDER BY id DESC ';

/* Pagination Code starts */
$per_page_html = '';
$page = 1;
$start=0;
if(!empty($_POST["page"])) {
  $page = $_POST["page"];
  $start=($page-1) * ROW_PER_PAGE;
}
$limit=" limit " . $start . "," . ROW_PER_PAGE;
$pagination_statement = $conn->prepare($sql);
$pagination_statement->bindValue(':keyword', '%' . $search_keyword . '%', PDO::PARAM_STR);
$pagination_statement->execute();

$row_count = $pagination_statement->rowCount();
if(!empty($row_count)){
  $per_page_html .= "<div style='text-align:center;margin:20px 0px;'>";
  $page_count=ceil($row_count/ROW_PER_PAGE);
  if($page_count>1) {
    for($i=1;$i<=$page_count;$i++){
      if($i==$page){
        $per_page_html .= '<input type="submit" name="page"  value="' . $i . '" class="aa btn-page current " style="" />';
      } else {
        $per_page_html .= '<input type="submit" name="page" value="' . $i . '" class="aa btn-page" style=""/>';
      }
    }
  }
  $per_page_html .= "</div>";
}

$query = $sql.$limit;
$pdo_statement = $conn->prepare($query);
$pdo_statement->bindValue(':keyword', '%' . $search_keyword . '%', PDO::PARAM_STR);
$pdo_statement->execute();
$result = $pdo_statement->fetchAll();

?>




<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Quiz Module</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

      <div class="row">

        <div class="col-lg-1 col-md-1 col-sm-0 col-xs-0">
        </div>

        <div class="col-lg-5 col-md-5 col-sm-6 col-xs-4">
          <div class="form" style="margin:0px;">
            <p>&nbsp;</p>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-8" >

            <form name='frmSearch' action='' method='post' class="form" style="">
              <div style='text-align:right;margin-left:50px;'>
                <input type="text" name='search[keyword]' value="<?php echo $search_keyword; ?>" placeholder="Search..." id='keyword' maxlength='25' class="input-text4 ad-form" style="">
                <!--<button type="submit" name="search" class="input-btn input-text2 ad-move" style="width:60px"><i class="i-con22 fa fa-search" style="font-size:15px;"></i></button>-->
              </div>
        </div>
      </div>

    </div>
  </div>
</section>



<section class="" id="aboutUs" style="padding-top:0px;margin-top:0px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">

      <div class="col-lg-2 col-md-2 col-sm-0 col-xs-0">
      </div>

      <div class="col-lg-8 col-md-8 col-sm-12 wow fadeInLeft delay-03s text-purple card" style="">
        <h3><strong>List of Quiz module</strong></h3>

          <table class='tbl-qa gfg' style="width:100%;" >
            <tbody id='table-body'>
              <thead>
            	<tr>
            	  <th class='table-header geeks geeks-m1'></th>
            	  <th class='table-header geeks geeks-m2'></th>
            	</tr>
              </thead>
            <?php
            if(!empty($result)) {
              foreach($result as $row) {
                $id = $row['id'];
                $quiz_id = $row['quiz_id'];
                $category = $row['category'];
            ?>
              <tr class='table-row card1 desk-v' style="margin-top:-20px;">
                <td class="geeks" width="60%" style='padding:10px;'><h5 class="title-learn " style="padding-left:10px;">Quiz: <?php echo $row['title']; ?></h5></td>
                <td class="geeks" width="40%" style='padding:10px;'><a class="text-purple" href="quiz-attempt-student.php<?php echo '?tb_quiz_modul='.$id; ?>"><div class="btn-icon"><center><i class="i-con22 fa fa-sign-in" style="font-size:25px;"></i></center></div></a>
                </td>
              </tr>

              <tr class='mobile-v table-row card1' style="height:auto;margin-top:20px;padding-bottom:50px;">
                <td class="geeks"><h5 class="title-learn " style="padding-left:10px;">Chapter <?php echo $row['chapter']; ?> : <?php echo $row['title']; ?></h5></td>
              </tr>
              <tr class="mobile-v table-row" style="margin-top:-60px;margin-right: 10px;height:50px;">
                <td class="geeks mobile-v table-row">
                  <a class="text-purple" href="quiz-attempt-student.php<?php echo '?tb_quiz_modul='.$id; ?>"><div class="btn-icon"><center><i class="i-con22 fa fa-sign-in" style="font-size:25px;"></i></center></div></a>
                </td>
                </tr>
              <?php
              }
            }
            ?>
            </tbody>
          </table>

        <?php echo $per_page_html; ?>
        </form>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-0 col-xs-0">
      </div>

  </div>
  </div>
</section>


<br><BR><BR><BR><br><BR><BR><BR>

<?php include("php/footer-student.php"); ?>
