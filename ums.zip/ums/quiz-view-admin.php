<?php
define("ROW_PER_PAGE",9);
include("php/header-admin.php") ;
error_reporting(0);

    $get_id=$_GET['tb_quiz_modul'];

    $s = $conn ->prepare("SELECT * FROM tb_question WHERE category='$get_id'");
    $s ->execute();

    $s1 = $conn ->prepare("SELECT * FROM tb_quiz_modul WHERE quiz_id='$get_id'");
    $s1 ->execute();
    $row23 = $s1->fetch();

?>

<style>
input:read-only { background: #bbbbbb; }
}
</style>


<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>View Quiz Module</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->


<section class="page_section" id="clients" style="padding:0px;border-top:10px solid #392560;background:white;">
  <div class="client_logos" style="width:auto;padding:20px; background:white;padding-bottom:30px"><!--client_logos-->
    <div class="container">

    </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:70px;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-0" style=""></div>
      <div class="col-lg-8 col-md-8 col-sm-12 wow fadeInLeft delay-06s up1 text-purple card ad-margin" style="">
        <h4 class="title-learn aa13"><u>Details</u></h4>
          <p>Title: <b><?php echo $row23['title'];  ?></b> </p>
          <p>Duration: <b><?php echo $row23['quiz_time'];  ?> minutes</b> </p>
          <p>Description: <b><?php echo $row23['description'];  ?></b> </p>
      </div>
      <div class="col-lg-2 col-md-2 col-sm-0" style=""></div>

    </div>

  </div>
  </div>
</section>

<section id="aboutUs" style="padding-top:0px;"><!--Aboutus-->
  <div class="inner_wrapper">
    <div class="container">

      <div class="row" >

        <div class="col-lg-6 col-md-6 col-sm-0 col-xs-0">
        </div>


      </div>

      <div class="row" >
        <h3 class="text-purple text-left jjs" style="font-size:25px;margin-left:15px"><u><strong>List of Questions</strong></u></h3><br>

        <?php

        for($i=0; $row = $s->fetch(); $i++)
        {

          $id = $row['id'];
          $chapter_id = $row['category'];
          $category = $row['quest_id'];

          $sql21 = $conn ->prepare("SELECT * FROM tb_choices WHERE quest_id='$category';");
          $sql21 ->execute();

          $sql211 = $conn ->prepare("SELECT * FROM tb_choices WHERE is_right='1' AND quest_id='$category';");
          $sql211 ->execute();

        ?>

            <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft up2 delay-06s">
              <div id="col2" class="col-lg-12 col-md-12 col-sm-12 wow fadeInLeft delay-06s up2 text-purple card" style="padding:8px;">

                  <br>
                  <h3 class=" aa12"><?php echo $row['quest_id']; ?></h3>
                  <h4 class="title-learn aa13" style="padding-left:10px;"><?php echo $row['quest']; ?></h4>
                  <?php
                    for($i11=1; $row211 = $sql211->fetch(); $i11++)
                    {
                      $anss=$row211['choices'];
                  ?>
                  <h4 class="title-learn aa13" style="padding-left:10px;">Ans: <strong><?php echo $anss; ?></strong></h4>
                  <?php } ?>
                  <ul>
                    <?php
                    for($i1=1; $row21 = $sql21->fetch(); $i1++)
                    {
                      $choices = $row21['choices'];
                    ?>
                    <li><span class="orgg" style="padding:0;">Option <?php echo $i1;?>&nbsp;</span> <?php echo $choices; ?></li>
                  <?php } ?>
                  </ul>
              </div>
            </div>

        <?php
      }
      ?>

      </div>
    </div>
  </div>
</section>


<section class="kosong ad-margin">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>

      <div class="col-lg-4 col-md-4 col-sm-12 wow fadeInLeft delay-06s up1 text-purple" style="">
        <div class="form">
          <a href="quiz.php"><input class="input-btn" name="submit" type="submit" value="Back" style="width:100%;background:#ffa248"></a>
        </div>
      </div>

      <div class="col-lg-4 col-md-4 col-sm-0">
      </div>
    </div>
</section>


<?php include("php/footer-admin.php"); ?>
