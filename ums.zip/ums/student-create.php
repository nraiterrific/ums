<?php

include("php/header-admin.php");

require "connection.php";

    if(isset($_POST['submit'])) {

    $name=$_POST['name'];
    $matrix=$_POST['matrix'];
    $username=$_POST['username'];
    $password=$_POST['password'];
    $student_id = uniqid();

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO tb_student (name, matrix, username, password, student_id)
            VALUES ('$name', '$matrix', '$username', '$password', '$student_id')";

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    ?><script>
    alert('Successfully added');</script>
    <?php
    echo "<script>window.location='student-admin.php'</script>";
}

?>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Update data student</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section id="aboutUs"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>

      <div class="col-lg-8 col-md-8 col-sm-10 wow fadeInLeft delay-06s up1 text-purple card">

        <h3>Registration form</h3><br>
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <label class="">Fullname</label>
          <input class="input-text2" type="text" name="name" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" required>

          <label class="">Matrix Number</label>
          <input class="input-text2" type="text" name="matrix" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" required>

          <label class="">Username</label>
          <input class="input-text2" type="text" name="username" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" required>

          <label class="">Password</label>
          <input class="input-text2" type="password" name="password" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;" required>

          <!--<label class="">Confirm Password</label>
          <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

          <input class="input-btn" name="submit" type="submit" value="Create" style="width:100%">
        </form>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>
    </div>

  </div>
  </div>
</section>


<?php include("php/footer-admin.php"); ?>
