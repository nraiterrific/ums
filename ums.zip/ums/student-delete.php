

    <?php
    require_once('connection.php');

    $get_id=$_GET['tb_student'];

    // sql to delete a record
    $sql = "Delete from tb_student where id = '$get_id'";

    // use exec() because no results are returned
    $conn->exec($sql);
    echo "<script>alert('Successfully deleted !'); window.location='student-admin.php'</script>";
    ?>
