<?php

include("php/header-admin.php");

$get_id=$_GET['tb_student'];

try{
    if(isset($_POST['submit'])) {

      $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "UPDATE tb_student SET
                name=:name,
                matrix=:matrix,
                username=:username,
                password=:password
                 WHERE id=$get_id";

        $stmt = $conn->prepare($sql);
        $stmt -> bindParam (":name", $_POST['name'], PDO::PARAM_STR);
        $stmt -> bindParam (":matrix", $_POST['matrix'], PDO::PARAM_STR);
        $stmt -> bindParam (":username", $_POST['username'], PDO::PARAM_STR);
        $stmt -> bindParam (":password", $_POST['password'], PDO::PARAM_STR);

        $stmt->execute();
        ?><script>
        alert('Successfully updated');</script>
        <?php
        echo "<script>window.location='student-admin.php'</script>";

    }
  } catch(PDOException $e){
      die("ERROR: Could not able to execute $sql2. " . $e->getMessage());
  }

  //*****************************************************************************
  $sql2 = $conn ->prepare("SELECT * FROM tb_student WHERE id='$get_id'");
  $sql2 ->execute();
  for($i=0; $row2 = $sql2->fetch(); $i++)
  {
    $id = $row2['id'];


?>

<section id="aboutUs" style="background:#8fc24b;padding-bottom:0px;width:100%; margin:0 auto;"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">
    <h2><strong>Add new student</strong></h2>
    <h3 class="text-center" style="">E-Learning Basic Mandarin</h3><br><BR>
    <!--<center>
      <img src="img/brainstorm.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/scholarship.png" alt="logo" width="60">&nbsp;&nbsp;
      <img src="img/question.png" alt="logo" width="60">
    </center>-->
    <div class="inner_section">
	   <div class="row">

    	<div class=" col-lg-7 col-md-7 col-sm-7 col-xs-12 pull-left">
      	<div class=" delay-01s animated fadeInDown wow animated">

        </div>
       </div>
      </div>
     </div>
    </div>
  </div>
</section>
<!--bannner-->

<section id="aboutUs"><!--Aboutus-->
<div class="inner_wrapper">
  <div class="container">

    <div class="row">
      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>

      <div class="col-lg-8 col-md-8 col-sm-10 wow fadeInLeft delay-06s up1 text-purple card">
        <form method="post" class="form" enctype="multipart/form-data" style="border:none;">

          <label class="">Fullname</label>
          <input class="input-text2" type="text" name="name" value="<?php echo $row2['name']; ?>">

          <label class="">Matrix Number</label>
          <input class="input-text2" type="text" name="matrix" value="<?php echo $row2['matrix']; ?>">

          <label class="">Username</label>
          <input class="input-text2" type="text" name="username" value="<?php echo $row2['username']; ?>">

          <label class="">Password</label>
          <input class="input-text2" type="password" name="password" value="<?php echo $row2['password']; ?>">

          <!--<label class="">Confirm Password</label>
          <input class="input-text2" type="password" name="" value="" onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;">-->

          <input class="input-btn" name="submit" type="submit" value="Update" style="width:100%">
        </form>
      </div>

      <div class="col-lg-2 col-md-2 col-sm-1">
      </div>
    </div>

  </div>
  </div>
</section>

<?php } //close for for ?>

<?php include("php/footer-admin.php"); ?>
