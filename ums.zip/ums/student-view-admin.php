<?php

include("php/header-admin.php");

?>

<?php
  $get_id=$_GET['tb_student'];
  $sql = $conn ->prepare("SELECT * FROM tb_student WHERE id=$get_id");
  $sql ->execute();
  for($i=0; $row2 = $sql->fetch(); $i++)
  {
    $id = $row2['id'];
?>
<!--Hero_Section-->
<section id="hero_section" class="top_cont_outer" style="background-image: url(img/bg17.jpg); background-position: center; background-repeat: no-repeat;background-size: cover;">
  <div class="hero_wrapper">
    <div class="container">
      <div class="hero_section">
        <div class="row">

          <div class="col-lg-3 col-sm-0"></div>

          <center>
            <div class="col-lg-6 col-sm-12 card s-card-p" >
            <img src="img/teamwork.png" width="200"><br><BR>
            <h2 class="text-purple size-h2"><strong><?php echo $row2['name']; ?></strong></h2>
            <h5 class="text-purple size-h5">as Student Role</h5>
            <br>

              <div class="row" style="border-top:1px solid #ccc; width:90%;">
                <div class="col-lg-12 col-sm-0">
                  <br><BR>
                  <h3 class="text-purple text-left">Matrix: <?php echo $row2['matrix']; ?></h3><BR>
                    <h3 class="text-purple text-left" style="margin-top:-20px;">Username: <?php echo $row2['username']; ?></h3><BR>
                  <a href="student-admin.php"><input class="btn-up-l" name="submit" type="submit" value="Back" style="width:100%"></a>
                </div>
              </div>

            </div>
          </center>

          <div class="col-lg-3 col-sm-0 wow fadeInLeft delay-06s up1"></div>

        </div>

      </div>
    </div>
  </div>
</section>

<?php } ?>
<!--Hero_Section-->



<?php include("php/footer-admin.php"); ?>
